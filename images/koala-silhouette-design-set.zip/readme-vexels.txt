 DESIGNED  BY VEXELS.COM 


  						     
Thanks for downloading our stuff. Created with LOVE by Vexels Team. 
 

Some of our graphics are free to use, as long as we are credited: "Designed by Vexels" wherever the graphic is used.  

You can avoid giving attribution and enjoy many other benefits by becoming a subscriber or buying an individual license. Check: https://www.vexels.com/plans/rmt


Within our subscription plans you�ll gain access to tons of LICENSED GRAPHICS, PREMIUM CONTENT, PRIORITY SUPPORT and many other advantages. 

REMEMBER: Using our graphics without a proper license or attribution will be considered a COPYRIGHT INFRINGEMENT.  


Enjoy our graphics and have fun designing!

-Vexels- 